#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include <vector>
using namespace std;

//Rawan's part
class Planet : public Moon
{
private:

    string Type;
    string Time;
    string planet_name;
    int planet_num;

public:
    vector <Moon> moon_array;

    //default constructor
    Planet()
    {
        planet_name  = " ";
        Type = " ";
        Time = " ";
    }

    //setters & getters for planet class
    void set_planet_name(string name)
    {
        planet_name = name;
    }

    string get_name_planet()
    {
        return planet_name;
    }

    void set_planet_num(int num)
    {
        planet_num = num;
    }

    int get_planet_num()
    {
        return planet_num;
    }

    void set_type(string type)
    {
        Type = type;
    }

    string get_type()
    {
        return Type;
    }
    
    void set_time(string time)
    {
        Time = time;
    }

    string get_time()
    {
        return Time;
    }

    //function for search for a planet
    void search(string name)
    {
        if (planet_name == name)
        {
            display();
        }
    }

    //Salma's part (display info about planets)
    void display()
    {
        cout << endl << "-----------------------------------------------\n";
        cout << "Information about it:\n";
        cout << "1) Radius: " << get_radius() << endl;
        cout << "2) Mass: " << get_mass() << endl;
        cout << "3) Density: " << get_density() << endl;
        cout << "4) Gravity: " << get_gravity() << endl;
        cout << "5) Type: " << Type << endl;
        cout << "6) Time (compared to Earth's time): " << Time << endl;
    }

    void planet_info()
    {
        if(planet_num == 1)
        {
            cout << "This is the closest planet to the sun " << endl << "It's called Mercury, ";
            cout << "it's about 4900 km away from the sun. It orbits the Sun in 87.97 Earth days,";
            cout << " the shortest year of all the Sun's planets. It is named after the Roman god Mercurius (Mercury),";
            cout << " god of commerce, messenger of the gods, and mediator between gods and mortals. ";
            cout << "Mercury orbits the Sun within Earth's orbit as an inferior planet." << endl;
        }
        else if (planet_num == 2)
        {
            cout << "This is Venus. It's the second planet from the Sun. It is sometimes called Earth's\"sister\"";
            cout << " planet, as it is almost as large and has a similar composition. Venus, like Mercury, appears in Earth's sky.";
            cout << "Like Mercury, Venus doesn't have any moons. Solar days on Venus are 117 Earth days.";
            cout << " Venus is orbiting the Sun every 224.7 Earth days." << endl;
        }
        else if(planet_num == 3)
        {
            cout << "This is our mother \"Earth\", ";
            cout << "the third planet from the Sun and the ONLY astronomical object known to harbor life.";
            cout << " While large volumes of water can be found throughout the Solar System, only Earth sustains liquid surface water. ";
            cout << "About 71 percent of Earth's surface is made up of oceans. ";
            cout << "The atmosphere of Earth consists mostly of nitrogen and oxygen, Greenhouse gases.";
            cout << " Earth is about eight light minutes away from the Sun and orbits it, taking a year (about 365.25 days) to complete one revolution.";
            cout << " The Earth rotates around its own axis in slightly less than a day (in about 23 hours and 56 minutes)." << endl;
        }
        else if(planet_num == 4)
        {
            cout << "Introducing our last rocky planet, \"Mars\". ";
            cout << "Mars is the fourth planet from the Sun and the second smallest planet in the Solar System, only being larger than Mercury. ";
            cout << "In the English language, Mars is named for the Roman god of war. ";
            cout << "Mars can be viewed from Earth with the naked eye, as can its reddish coloring. This appearance, ";
            cout << "due to the iron oxide prevalent on its surface, has led to Mars often being called the Red Planet. ";
            cout << "Historically, Mars has been observed since ancient times, and over the millennia has been featured ";
            cout << "in cultures and arts in ways that have reflected humanity's growing knowledge of it." << endl;
        }
        else if(planet_num == 5)
        {
            cout << "Jupiter, the first Gaseous planet and the fifth planet from the Sun and the largest in the Solar System. ";
            cout << "Jupiter is the third brightest natural object in the Earth's night sky after the Moon and Venus. ";
            cout << "Jupiter has 82 known moons and likely many more, including the four large moons discovered by Galileo Galilei in 1610." << endl;
        }
        else if(planet_num == 6)
        {
            cout << "This is the secound gaseous planet, \"Saturn\"";
            cout << " It's the sixth planet from the Sun and the second-largest in the Solar System, after Jupiter. ";
            cout << "Saturn's interior is most likely composed of a core of iron-nickel and rocks (silicon and oxygen compounds). ";
            cout << "Saturn has a pale yellow hue due to ammonia crystals in its upper atmosphere. ";
            cout << "The planet's most notable feature is its prominent ring system, ";
            cout << "which is composed mainly of ice particles, with a smaller amount of rocky debris and dust. ";
            cout << "At least 83 moons are known to orbit Saturn, of which 53 are officially named, ";
            cout << "this does not include the hundreds of moonlets in its rings." << endl;
        }
        else if(planet_num == 7)
        {
            cout << "Uranus, the first ice planet and the seventh planet from the Sun. ";
            cout << "It has the third-largest planetary radius and fourth-largest planetary mass in the Solar System. ";
            cout << "It has the coldest planetary atmosphere in the Solar System, with a minimum temperature of 49 K (-224 C; -371 F)";
            cout << " Like the other giant planets, Uranus has a ring system, a magnetosphere, and numerous moons. ";
            cout << "Voyager 2 remains the only spacecraft to visit the planet. Observations from Earth ";
            cout << "have shown seasonal change and increased weather activity as Uranus approached its equinox in 2007. ";
            cout << "Wind speeds can reach 250 metres per second (900 km/h; 560 mph)." << endl;
        }
        else if(planet_num == 8)
        {
            cout << "Neptune, the other \"ice gaint\" and the eighth planet from the Sun and the farthest known planet in the Solar System. ";
            cout << "It's the fourth-largest planet in the Solar System by diameter, the third-most-massive planet, slightly more massive than its near-twin Uranus. ";
            cout << "Like Jupiter and Saturn, Neptune's atmosphere is composed primarily of hydrogen and helium, along with traces of hydrocarbons and possibly nitrogen, ";
            cout << "though it contains a higher proportion of ices such as water,ammonia and methane. ";
            cout << "Neptune's atmosphere has active and visible weather patterns." << endl;
        }
        else
        {
            cout << "There's only 8 planets try numbers from 1 to 8." << endl;
        }
    }
};

//Alaa's part
class Moon
{
private :
    string around_planet;
    string moon_type;
    string moon_name;
    float Radius;
    float Mass;
    float Density;
    float Gravity;

public:

    //default constructor for moon
    Moon()
    {
        Radius = 0.0;
        Mass = 0.0;
        Density = 0.0;
        Gravity = 0.0;
        around_planet = " ";
        moon_type = " ";
        moon_name = " ";
    }

    //setters & getters for moon class
    void set_around_planet(string ap)
    {
        around_planet = ap;
    }

    string get_around_planet()
    {
        return around_planet;
    }

    void set_moon_type(string mt)
    {
        moon_type = mt;
    }

    string get_moon_type()
    {
        return moon_type;
    }

    void set_moon_name(string  mn)
    {
        moon_name = mn;
    }

    string  get_moon_name()
    {
        return moon_name;
    }

    void set_radius(float r)
    {
        Radius = r;
    }

    float get_radius()
    {
        return Radius;
    }

    void set_mass(float m)
    {
        Mass = m;
    }

    float get_mass()
    {
        return Mass;
    }

    void set_density(float d)
    {
        Density = d;
    }
    
    float get_density()
    {
        return Density;
    }

    void set_gravity(float g)
    {
        Gravity = g;
    }

    float get_gravity()
    {
        return Gravity;
    }

    //Salam's part (display info about moons)
    void dispaly()
    {
        cout << endl << "-----------------------------------------------\n";
        cout << "Information about it:\n";
        cout << "1) Radius: " << Radius << endl;
        cout << "2) Mass: " << Mass << endl;
        cout << "3) Density: " << Density << endl;
        cout << "4) Gravity: " << Gravity << endl;
        cout << "5) This moon revolves around planet: "<<around_planet<<endl;
        cout << "6) Moon type: " << moon_type << endl;
        cout << "7) Moon name: " << moon_name << endl;
        cout << "-----------------------------------------------\n";
    }
};

//Esraa's part
class Sun
{
    int temp_surface ;
    int temp_core ;
    int Speed_of_Light_in_Vacuum;
    float photon_travel_time;
    int Radius_of_the_earth;
    double Mass_of_the_earth;

public:
    Sun ()
    {
        temp_surface = 6000;
        temp_core = 15000000 ;
        Speed_of_Light_in_Vacuum = 300000;
        Radius_of_the_earth = 6371;
        Mass_of_the_earth = 5.9722 * pow(10,24);
    }

    void Distance_of_planets_from_Sun ()
    {
        cout << "Distance of planets from the sun : " << endl <<endl;

        cout << "Distance of Mercury from the Sun is : " << distance_from_sun(193) << " km." << endl << endl;
        cout << "------------------------------------------------------------" << endl << endl;

        cout << "Distance of Venus from the Sun is : " << distance_from_sun(360) << " km." << endl << endl;
        cout << "------------------------------------------------------------" << endl << endl;

        cout << "Distance of Earth from the Sun is : " << distance_from_sun(499) << " km." << endl << endl;
        cout << "------------------------------------------------------------" << endl << endl;

        cout << "Distance of Mars from the Sun is : " << distance_from_sun(759.9) << " km." << endl << endl;
        cout << "------------------------------------------------------------" << endl << endl;

        cout << "Distance of Jupiter from the Sun is : " << distance_from_sun(2595) << " km." << endl << endl;
        cout << "------------------------------------------------------------" << endl << endl;

        cout << "Distance of Saturn from the Sun is : " << distance_from_sun(4759) << " km." << endl << endl;
        cout << "------------------------------------------------------------" << endl << endl;

        cout << "Distance of Uranus from the Sun is : " << distance_from_sun(9575) << " km." << endl << endl;
        cout << "------------------------------------------------------------" << endl << endl;

        cout << "Distance of Neptune from the Sun is : " << distance_from_sun(14998) << " km." << endl << endl;
        cout << "------------------------------------------------------------" << endl << endl;

        cout << "Distance of Pluto/ Kuiper belt from the Sun is : " << distance_from_sun(19680) << " km." << endl << endl;
        cout << "------------------------------------------------------------" << endl << endl;
    }

    int  get_Temperature_on_surface()
    {
        return temp_surface;
    }

    int get_Temperature_of_core ()
    {
        return temp_core;
    }

    float distance_from_sun(float photon_travel)
    {
        float Distance;
        Distance = Speed_of_Light_in_Vacuum * photon_travel;

        return Distance;
    }

    double Mass_of_the_Sun()
    {
        double Sun_mass;

        Sun_mass = Mass_of_the_earth * 330000;

        return Sun_mass;
    }

    int Radius_of_the_Sun()
    {
        int Sun_radius;

        Sun_radius = Radius_of_the_earth * 109;

        return Sun_radius;
    }

    void Elements_of_Sun (string h,string he)
    {
        h = "hydrogen";
        he = "helium";
        cout << "Sun elements : " << "Roughly three-quarters of the Sun's mass consists of : " << h << " (~73%); the rest is mostly " << he <<" (~25%) ."<<endl ;
    }

    void Elements_of_Sun (string o,string c,string n,string fe)
    {
        o = "oxygen";
        c = "carbon";
        n = "neon";
        fe = "iron";
        cout << " with much smaller quantities of heavier elements, including : " << o << " , " << c << " , " << n << " and " << fe  << " ."<<endl;
    }

    void display()
    {
        cout << "Information about the sun:" << endl;
        cout << "1) Sun's mass: " << Mass_of_the_Sun() << endl;
        cout << "2) Sun's radius: " << Radius_of_the_Sun() << endl;
        cout << "3) ";
        Elements_of_Sun("hydrogen", "helium");
        cout << "4) ";
        Elements_of_Sun("oxygen", "carbon", "neon", "iron");
        cout << "5) ";
        Distance_of_planets_from_Sun();
        cout<<endl;
    }

};

int main() {
    
    
    return 0;
}