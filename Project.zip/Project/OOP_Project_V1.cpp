#include <iostream>
#include <string>
#include <math.h>
using namespace std;

//Esraa's part
class Sun 
{
    int temp_surface ;
    int temp_core ;
    int Speed_of_Light_in_Vacuum;
    float photon_travel_time;
    int Radius_of_the_earth;
    double Mass_of_the_earth;

public:
    Sun ()
    {
        temp_surface = 6000;
        temp_core = 15000000 ;
        Speed_of_Light_in_Vacuum = 300000;
        Radius_of_the_earth = 6371;
        Mass_of_the_earth = 5.9722 * pow (10,24); 
    }

    float distance_from_sun(float photon_travel)
    {
        float Distance;
        Distance = Speed_of_Light_in_Vacuum * photon_travel;

        return Distance;
    }

    void Distance_of_planets_from_Sun ()
    {
        cout << endl << endl << "Distance of planets from the sun : " << endl << endl;

        cout << "Distance of Mercury from the Sun is : " << distance_from_sun(193) << " km " << endl << endl; 
        cout << "------------------------------------------------------------" << endl << endl;

        cout << "Distance of Venus from the Sun is : " << distance_from_sun(360) << " km " << endl << endl; 
        cout << "------------------------------------------------------------" << endl << endl;

        cout << "Distance of Earth from the Sun is : " << distance_from_sun(499) << " km " << endl << endl;   
        cout << "------------------------------------------------------------" << endl << endl;

        cout << "Distance of Mars from the Sun is : " << distance_from_sun(759.9) << " km " << endl << endl; 
        cout << "------------------------------------------------------------" << endl << endl; 

        cout << "Distance of Jupiter from the Sun is : " << distance_from_sun(2595) << " km " << endl << endl; 
        cout << "------------------------------------------------------------" << endl << endl;

        cout << "Distance of Saturn from the Sun is : " << distance_from_sun(4759) << " km " << endl << endl;
        cout << "------------------------------------------------------------" << endl << endl;

        cout << "Distance of Uranus from the Sun is : " << distance_from_sun(9575) << " km " << endl << endl; 
        cout << "------------------------------------------------------------" << endl << endl;

        cout << "Distance of Neptune from the Sun is : " << distance_from_sun(14998) << " km " << endl << endl; 
        cout << "------------------------------------------------------------" << endl << endl;

        cout << "Distance of Pluto/ Kuiper belt from the Sun is : " << distance_from_sun(19680) << " km " << endl << endl; 
        cout << "------------------------------------------------------------" << endl << endl;
    }
    
    int  get_Temperature_on_surface()
    {
        return temp_surface;
    }

    int get_Temperature_of_core ()
    {
        return temp_core;
    }

    double Mass_of_the_Sun()
    {
        double Sun_mass;

        Sun_mass = Mass_of_the_earth * 330000;
        
        return Sun_mass;
    }

    int Radius_of_the_Sun()
    {   
        int Sun_radius;

        Sun_radius = Radius_of_the_earth * 109;
        
        return Sun_radius;
    }

    void Elements_of_Sun (string h, string he)
    {
        h = "hydrogen";
        he = "helium";
        cout << "Sun elements : " << endl << endl << "Roughly three-quarters of the Sun's mass consists of : " << h << " (~73%); the rest is mostly " << he <<" (~25%) ." ;
    }

    void Elements_of_Sun (string o, string c, string n, string fe)
    {
        o = "oxygen";
        c = "carbon";
        n = "neon";
        fe = "iron";
        cout << " with much smaller quantities of heavier elements, including : " << o << " , " << c << " , " << n << " and " << fe  << " ." << endl << endl;
        cout << "------------------------------------------------------------" << endl << endl;
    }

    void Elements_of_sun()
    {
        string H = "hydrogen";
        string He = "helium";
        string O = "oxygen";
        string C = "carbon";
        string Ne = "neon";
        string Fe = "iron";

        cout << "The sun's elements are: " << endl << endl;
        cout << "Roughly three-quarters of the sun's mass consists of : " << H << " (~73%); the rest is mostly " << He <<" (~25%) ." ;
        cout << "With much smaller quantities of heavier elements, including " << O << ", " << C << ", " << Ne << " and " << Fe  << "." << endl << endl;
    }
};

