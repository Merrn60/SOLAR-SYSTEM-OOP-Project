#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
using namespace std;

//Alaa's part
class Moon
{
private :
    string around_planet;
    string moon_type;
    string moon_name;
    float Radius;
    float Mass;
    float Density;
    float Gravity;

public:

    //default constructor for moon
    Moon()
    {
        Radius = 0.0;
        Mass = 0.0;
        Density = 0.0;
        Gravity = 0.0;
        around_planet = " ";
        moon_type = " ";
        moon_name = " ";
    }

    //setters & getters for moon class
    void set_around_planet(string ap)
    {
        around_planet = ap;
    }

    string get_around_planet()
    {
        return around_planet;
    }

    void set_moon_type(string mt)
    {
        moon_type = mt;
    }

    string get_moon_type()
    {
        return moon_type;
    }

    void set_moon_name(string  mn)
    {
        moon_name = mn;
    }

    string  get_moon_name()
    {
        return moon_name;
    }

    void set_radius(float r)
    {
        Radius = r;
    }

    float get_radius()
    {
        return Radius;
    }

    void set_mass(float m)
    {
        Mass = m;
    }

    float get_mass()
    {
        return Mass;
    }

    void set_density(float d)
    {
        Density = d;
    }
    
    float get_density()
    {
        return Density;
    }

    void set_gravity(float g)
    {
        Gravity = g;
    }

    float get_gravity()
    {
        return Gravity;
    }

    //Salam's part (display info about moons)
    void dispaly()
    {
        cout << endl << "-----------------------------------------------\n";
        cout << "Information about it:\n";
        cout << "1) Radius: " << Radius << endl;
        cout << "2) Mass: " << Mass << endl;
        cout << "3) Density: " << Density << endl;
        cout << "4) Gravity: " << Gravity << endl;
        cout << "5) This moon revolves around planet: "<<around_planet<<endl;
        cout << "6) Moon type: " << moon_type << endl;
        cout << "7) Moon name: " << moon_name << endl;
        cout << "-----------------------------------------------\n";
    }
};

//Rawan's part
class Planet : public Moon
{
private:

    string Type;
    int Time;
    string planet_name;
    int planet_num;
    int num_of_moons;

public:
    Moon moon_array[2];

    //default constructor
    Planet()
    {
        planet_num = 0;
        num_of_moons = 0;
        planet_name  = " ";
        Type = " ";
        Time = 0;
    }

    //setters & getters for planet class
    void set_planet_name(string name)
    {
        planet_name = name;
    }

    string get_name_planet()
    {
        return planet_name;
    }

    void set_num_of_moons(int num_moons)
    {
        num_of_moons = num_moons;
    }

    int get_num_of_moons()
    {
        return num_of_moons;
    }

    void set_planet_num(int num)
    {
        planet_num = num;
    }

    int get_planet_num()
    {
        return planet_num;
    }

    void set_type(string type)
    {
        Type = type;
    }

    string get_type()
    {
        return Type;
    }
    
    void set_time(int time)
    {
        Time = time;
    }

    int get_time()
    {
        return Time;
    }

    //function for search for a planet
    void search(string name)
    {
        if (planet_name == name)
        {
            display();
        }
    }

    //Salma's part (display info about planets)
    void display()
    {
        cout << endl << "-----------------------------------------------\n";
        cout << "Information about it:\n";
        cout << "1) Radius: " << get_radius() << endl;
        cout << "2) Mass: " << get_mass() << endl;
        cout << "3) Density: " << get_density() << endl;
        cout << "4) Gravity: " << get_gravity() << endl;
        cout << "5) Type: " << Type << endl;
        cout << "6) Time (compared to Earth's time): " << Time << endl;
        cout << "7) Number of moons: " << num_of_moons << endl;
    }

    void planet_info()
    {
        if(planet_num == 1)
        {
            cout << "This is the closest planet to the sun " << endl << "It's called Mercury, ";
            cout << "it's about 4900 km away from the sun. It orbits the Sun in 87.97 Earth days,";
            cout << " the shortest year of all the Sun's planets. It is named after the Roman god Mercurius (Mercury),";
            cout << " god of commerce, messenger of the gods, and mediator between gods and mortals. ";
            cout << "Mercury orbits the Sun within Earth's orbit as an inferior planet." << endl;
        }
        else if (planet_num == 2)
        {
            cout << "This is Venus. It's the second planet from the Sun. It is sometimes called Earth's\"sister\"";
            cout << " planet, as it is almost as large and has a similar composition. Venus, like Mercury, appears in Earth's sky.";
            cout << "Like Mercury, Venus doesn't have any moons. Solar days on Venus are 117 Earth days.";
            cout << " Venus is orbiting the Sun every 224.7 Earth days." << endl;
        }
        else if(planet_num == 3)
        {
            cout << "This is our mother \"Earth\", ";
            cout << "the third planet from the Sun and the ONLY astronomical object known to harbor life.";
            cout << " While large volumes of water can be found throughout the Solar System, only Earth sustains liquid surface water. ";
            cout << "About 71 percent of Earth's surface is made up of oceans. ";
            cout << "The atmosphere of Earth consists mostly of nitrogen and oxygen, Greenhouse gases.";
            cout << " Earth is about eight light minutes away from the Sun and orbits it, taking a year (about 365.25 days) to complete one revolution.";
            cout << " The Earth rotates around its own axis in slightly less than a day (in about 23 hours and 56 minutes)." << endl;
        }
        else if(planet_num == 4)
        {
            cout << "Introducing our last rocky planet, \"Mars\". ";
            cout << "Mars is the fourth planet from the Sun and the second smallest planet in the Solar System, only being larger than Mercury. ";
            cout << "In the English language, Mars is named for the Roman god of war. ";
            cout << "Mars can be viewed from Earth with the naked eye, as can its reddish coloring. This appearance, ";
            cout << "due to the iron oxide prevalent on its surface, has led to Mars often being called the Red Planet. ";
            cout << "Historically, Mars has been observed since ancient times, and over the millennia has been featured ";
            cout << "in cultures and arts in ways that have reflected humanity's growing knowledge of it." << endl;
        }
        else if(planet_num == 5)
        {
            cout << "Jupiter, the first Gaseous planet and the fifth planet from the Sun and the largest in the Solar System. ";
            cout << "Jupiter is the third brightest natural object in the Earth's night sky after the Moon and Venus. ";
            cout << "Jupiter has 82 known moons and likely many more, including the four large moons discovered by Galileo Galilei in 1610." << endl;
        }
        else if(planet_num == 6)
        {
            cout << "This is the secound gaseous planet, \"Saturn\"";
            cout << " It's the sixth planet from the Sun and the second-largest in the Solar System, after Jupiter. ";
            cout << "Saturn's interior is most likely composed of a core of iron-nickel and rocks (silicon and oxygen compounds). ";
            cout << "Saturn has a pale yellow hue due to ammonia crystals in its upper atmosphere. ";
            cout << "The planet's most notable feature is its prominent ring system, ";
            cout << "which is composed mainly of ice particles, with a smaller amount of rocky debris and dust. ";
            cout << "At least 83 moons are known to orbit Saturn, of which 53 are officially named, ";
            cout << "this does not include the hundreds of moonlets in its rings." << endl;
        }
        else if(planet_num == 7)
        {
            cout << "Uranus, the first ice planet and the seventh planet from the Sun. ";
            cout << "It has the third-largest planetary radius and fourth-largest planetary mass in the Solar System. ";
            cout << "It has the coldest planetary atmosphere in the Solar System, with a minimum temperature of 49 K (-224 C; -371 F)";
            cout << " Like the other giant planets, Uranus has a ring system, a magnetosphere, and numerous moons. ";
            cout << "Voyager 2 remains the only spacecraft to visit the planet. Observations from Earth ";
            cout << "have shown seasonal change and increased weather activity as Uranus approached its equinox in 2007. ";
            cout << "Wind speeds can reach 250 metres per second (900 km/h; 560 mph)." << endl;
        }
        else if(planet_num == 8)
        {
            cout << "Neptune, the other \"ice gaint\" and the eighth planet from the Sun and the farthest known planet in the Solar System. ";
            cout << "It's the fourth-largest planet in the Solar System by diameter, the third-most-massive planet, slightly more massive than its near-twin Uranus. ";
            cout << "Like Jupiter and Saturn, Neptune's atmosphere is composed primarily of hydrogen and helium, along with traces of hydrocarbons and possibly nitrogen, ";
            cout << "though it contains a higher proportion of ices such as water,ammonia and methane. ";
            cout << "Neptune's atmosphere has active and visible weather patterns." << endl;
        }
        else
        {
            cout << "There's only 8 planets try numbers from 1 to 8." << endl;
        }
    }
};

//Esraa's part
class Sun
{
    int temp_surface ;
    int temp_core ;
    int Speed_of_Light_in_Vacuum;
    float photon_travel_time;
    int Radius_of_the_earth;
    double Mass_of_the_earth;

public:
    Sun ()
    {
        temp_surface = 6000;
        temp_core = 15000000 ;
        Speed_of_Light_in_Vacuum = 300000;
        Radius_of_the_earth = 6371;
        Mass_of_the_earth = 5.9722 * pow(10,24);
    }

    void Distance_of_planets_from_Sun ()
    {
        cout << "Distance of planets from the sun : " << endl <<endl;

        cout << "Distance of Mercury from the Sun is : " << distance_from_sun(193) << " km." << endl << endl;
        cout << "------------------------------------------------------------" << endl << endl;

        cout << "Distance of Venus from the Sun is : " << distance_from_sun(360) << " km." << endl << endl;
        cout << "------------------------------------------------------------" << endl << endl;

        cout << "Distance of Earth from the Sun is : " << distance_from_sun(499) << " km." << endl << endl;
        cout << "------------------------------------------------------------" << endl << endl;

        cout << "Distance of Mars from the Sun is : " << distance_from_sun(759.9) << " km." << endl << endl;
        cout << "------------------------------------------------------------" << endl << endl;

        cout << "Distance of Jupiter from the Sun is : " << distance_from_sun(2595) << " km." << endl << endl;
        cout << "------------------------------------------------------------" << endl << endl;

        cout << "Distance of Saturn from the Sun is : " << distance_from_sun(4759) << " km." << endl << endl;
        cout << "------------------------------------------------------------" << endl << endl;

        cout << "Distance of Uranus from the Sun is : " << distance_from_sun(9575) << " km." << endl << endl;
        cout << "------------------------------------------------------------" << endl << endl;

        cout << "Distance of Neptune from the Sun is : " << distance_from_sun(14998) << " km." << endl << endl;
        cout << "------------------------------------------------------------" << endl << endl;

        cout << "Distance of Pluto/ Kuiper belt from the Sun is : " << distance_from_sun(19680) << " km." << endl << endl;
        cout << "------------------------------------------------------------" << endl << endl;
    }

    int  get_Temperature_on_surface()
    {
        return temp_surface;
    }

    int get_Temperature_of_core ()
    {
        return temp_core;
    }

    float distance_from_sun(float photon_travel)
    {
        float Distance;
        Distance = Speed_of_Light_in_Vacuum * photon_travel;

        return Distance;
    }

    double Mass_of_the_Sun()
    {
        double Sun_mass;

        Sun_mass = Mass_of_the_earth * 330000;

        return Sun_mass;
    }

    int Radius_of_the_Sun()
    {
        int Sun_radius;

        Sun_radius = Radius_of_the_earth * 109;

        return Sun_radius;
    }

    void Elements_of_Sun (string h,string he)
    {
        h = "hydrogen";
        he = "helium";
        cout << "Sun elements : " << "Roughly three-quarters of the Sun's mass consists of : " << h << " (~73%); the rest is mostly " << he <<" (~25%) ."<<endl ;
    }

    void Elements_of_Sun (string o,string c,string n,string fe)
    {
        o = "oxygen";
        c = "carbon";
        n = "neon";
        fe = "iron";
        cout << " with much smaller quantities of heavier elements, including : " << o << " , " << c << " , " << n << " and " << fe  << " ."<<endl;
    }

    void display()
    {
        cout << "Information about the sun:" << endl;
        cout << "1) Sun's mass: " << Mass_of_the_Sun() << endl;
        cout << "2) Sun's radius: " << Radius_of_the_Sun() << endl;
        cout << "3) ";
        Elements_of_Sun("hydrogen", "helium");
        cout << "4) ";
        Elements_of_Sun("oxygen", "carbon", "neon", "iron");
        cout << "5) ";
        Distance_of_planets_from_Sun();
        cout << endl;
    }

};

int main() {
    //creating array of objects for rocky planets
    Planet rocky_planets[4];

    //entering info about Mercury
    rocky_planets[0].set_planet_name("mercury");
    rocky_planets[0].set_mass(3.285 * pow(10,23));
    rocky_planets[0].set_density(5.43);
    rocky_planets[0].set_gravity(3.7);
    rocky_planets[0].set_planet_num(1);
    rocky_planets[0].set_radius(2439.7);
    rocky_planets[0].set_time(88);
    rocky_planets[0].set_type("rocky");
    rocky_planets[0].set_num_of_moons(0);

    //entering info about Venus
    rocky_planets[1].set_planet_name("venus");
    rocky_planets[1].set_mass(4.867 * pow(10,24));
    rocky_planets[1].set_density(5.24);
    rocky_planets[1].set_gravity(8.87);
    rocky_planets[1].set_planet_num(2);
    rocky_planets[1].set_radius(6051.8);
    rocky_planets[1].set_time(225);
    rocky_planets[1].set_type("rocky");
    rocky_planets[0].set_num_of_moons(0);

    //entering info about Earth
    rocky_planets[2].set_planet_name("eartth");
    rocky_planets[2].set_mass(5.972 * pow(10,24));
    rocky_planets[2].set_density(5.51);
    rocky_planets[2].set_gravity(9.807);
    rocky_planets[2].set_planet_num(3);
    rocky_planets[2].set_radius(6371);
    rocky_planets[2].set_time(365);
    rocky_planets[2].set_type("rocky");
    rocky_planets[0].set_num_of_moons(1);

    //entering info about earth's moon
    rocky_planets[2].moon_array[0].set_moon_name("moon");
    rocky_planets[2].moon_array[0].set_moon_type("rocky");
    rocky_planets[2].moon_array[0].set_density(3.34);
    rocky_planets[2].moon_array[0].set_gravity(1.62);
    rocky_planets[2].moon_array[0].set_mass(7.34 * pow(10,22));
    rocky_planets[2].moon_array[0].set_radius(1737.4);
    rocky_planets[2].moon_array[0].set_around_planet("earth");

    //entering info about Mars
    rocky_planets[3].set_planet_name("mars");
    rocky_planets[3].set_mass(6.39 * pow(10,23));
    rocky_planets[3].set_density(3.93);
    rocky_planets[3].set_gravity(3.721);
    rocky_planets[3].set_planet_num(4);
    rocky_planets[3].set_radius(3389.5);
    rocky_planets[3].set_time(687);
    rocky_planets[3].set_type("rocky");
    rocky_planets[0].set_num_of_moons(2);

    //entering info about mars's first moon
    rocky_planets[2].moon_array[0].set_moon_name("phobos");
    rocky_planets[2].moon_array[0].set_moon_type("rocky");
    rocky_planets[2].moon_array[0].set_density(1.88);
    rocky_planets[2].moon_array[0].set_gravity(0.0057);
    rocky_planets[2].moon_array[0].set_mass(10.8 * pow(10,15));
    rocky_planets[2].moon_array[0].set_radius(11.267);
    rocky_planets[2].moon_array[0].set_around_planet("mars");

    //entering info about mars's second moon
    rocky_planets[2].moon_array[1].set_moon_name("deimos");
    rocky_planets[2].moon_array[1].set_moon_type("rocky");
    rocky_planets[2].moon_array[1].set_density(1.47);
    rocky_planets[2].moon_array[1].set_gravity(0.003);
    rocky_planets[2].moon_array[1].set_mass(1.8 * pow(10,15));
    rocky_planets[2].moon_array[1].set_radius(6.2);
    rocky_planets[2].moon_array[1].set_around_planet("mars");

    //creating array of objects for gaseous planets
    Planet gaseous_planets[4];

    //entering info about Jupiter
    gaseous_planets[0].set_planet_name("jupiter");
    gaseous_planets[0].set_mass(1.898 * pow(10,27));
    gaseous_planets[0].set_density(1.33);
    gaseous_planets[0].set_gravity(24.79);
    gaseous_planets[0].set_planet_num(5);
    gaseous_planets[0].set_radius(69911);
    gaseous_planets[0].set_time(4383);
    gaseous_planets[0].set_type("gaseous");
    gaseous_planets[0].set_num_of_moons(80);

    //entering info about jupiter's first moon
    gaseous_planets[0].moon_array[0].set_moon_name("europa");
    gaseous_planets[0].moon_array[0].set_moon_type("icy and rocky");
    gaseous_planets[0].moon_array[0].set_density(3.01);
    gaseous_planets[0].moon_array[0].set_gravity(1.315);
    gaseous_planets[0].moon_array[0].set_mass(4.7776 * pow(10,21));
    gaseous_planets[0].moon_array[0].set_radius(1560.8);
    gaseous_planets[0].moon_array[0].set_around_planet("jupiter");

    //entering info about jupiter's second moon
    gaseous_planets[0].moon_array[1].set_moon_name("ganymede");
    gaseous_planets[0].moon_array[1].set_moon_type("icy and rocky");
    gaseous_planets[0].moon_array[1].set_density(1.94);
    gaseous_planets[0].moon_array[1].set_gravity(1.428);
    gaseous_planets[0].moon_array[1].set_mass(1.4819 * pow(10,23));
    gaseous_planets[0].moon_array[1].set_radius(2634.1);
    gaseous_planets[0].moon_array[1].set_around_planet("jupiter");

    //entering info about Saturn
    gaseous_planets[1].set_planet_name("saturn");
    gaseous_planets[1].set_mass(5.683 * pow(10,26));
    gaseous_planets[1].set_density(0.69);
    gaseous_planets[1].set_gravity(10.44);
    gaseous_planets[1].set_planet_num(6);
    gaseous_planets[1].set_radius(58232);
    gaseous_planets[1].set_time(10592.2);
    gaseous_planets[1].set_type("gaseous");
    gaseous_planets[0].set_num_of_moons(83);

    //entering info about saturn's first moon
    gaseous_planets[1].moon_array[0].set_moon_name("titan");
    gaseous_planets[1].moon_array[0].set_moon_type("icy");
    gaseous_planets[1].moon_array[0].set_density(1.88);
    gaseous_planets[1].moon_array[0].set_gravity(1.352);
    gaseous_planets[1].moon_array[0].set_mass(1.3437 * pow(10,23));
    gaseous_planets[1].moon_array[0].set_radius(2574.7);
    gaseous_planets[1].moon_array[0].set_around_planet("saturn");

    //entering info about saturn's second moon
    gaseous_planets[1].moon_array[1].set_moon_name("enceladus");
    gaseous_planets[1].moon_array[1].set_moon_type("icy");
    gaseous_planets[1].moon_array[1].set_density(1.61);
    gaseous_planets[1].moon_array[1].set_gravity(0.113);
    gaseous_planets[1].moon_array[1].set_mass(1.08 * pow(10,20));
    gaseous_planets[1].moon_array[1].set_radius(252.1);
    gaseous_planets[1].moon_array[1].set_around_planet("saturn");

    //entering info about Uranus
    gaseous_planets[2].set_planet_name("uranus");
    gaseous_planets[2].set_mass(8.681 * pow(10,25));
    gaseous_planets[2].set_density(1.27);
    gaseous_planets[2].set_gravity(8.87);
    gaseous_planets[2].set_planet_num(7);
    gaseous_planets[2].set_radius(25362);
    gaseous_planets[2].set_time(30681);
    gaseous_planets[2].set_type("gaseous");
    gaseous_planets[0].set_num_of_moons(27);

    //entering info about uranus's first moon
    gaseous_planets[2].moon_array[0].set_moon_name("ariel");
    gaseous_planets[2].moon_array[0].set_moon_type("rocky");
    gaseous_planets[2].moon_array[0].set_density(1.59);
    gaseous_planets[2].moon_array[0].set_gravity(0.249);
    gaseous_planets[2].moon_array[0].set_mass(1.295 * pow(10,18));
    gaseous_planets[2].moon_array[0].set_radius(578.9);
    gaseous_planets[2].moon_array[0].set_around_planet("uranus");

    //entering info about uranus's second moon
    gaseous_planets[2].moon_array[1].set_moon_name("miranda");
    gaseous_planets[2].moon_array[1].set_moon_type("rocky");
    gaseous_planets[2].moon_array[1].set_density(1.2);
    gaseous_planets[2].moon_array[1].set_gravity(0.079);
    gaseous_planets[2].moon_array[1].set_mass(6.594 * pow(10,19));
    gaseous_planets[2].moon_array[1].set_radius(235.8);
    gaseous_planets[2].moon_array[1].set_around_planet("uranus");

    //entering info about Neptune
    gaseous_planets[3].set_planet_name("neptune");
    gaseous_planets[3].set_mass(1.024 * pow(10,26));
    gaseous_planets[3].set_density(1.64);
    gaseous_planets[3].set_gravity(11.15);
    gaseous_planets[3].set_planet_num(8);
    gaseous_planets[3].set_radius(24622);
    gaseous_planets[3].set_time(60225);
    gaseous_planets[3].set_type("gaseous");
    gaseous_planets[0].set_num_of_moons(14);

    //entering info about neptune's first moon
    gaseous_planets[3].moon_array[0].set_moon_name("triton");
    gaseous_planets[3].moon_array[0].set_moon_type("icy and rocky");
    gaseous_planets[3].moon_array[0].set_density(2.06);
    gaseous_planets[3].moon_array[0].set_gravity(0.779);
    gaseous_planets[3].moon_array[0].set_mass(2.144 * pow(10,22));
    gaseous_planets[3].moon_array[0].set_radius(1353.4);
    gaseous_planets[3].moon_array[0].set_around_planet("neptune");

    return 0;
}