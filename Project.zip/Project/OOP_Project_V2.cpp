#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
using namespace std;

//Rawan's part
class Planet
{
private:
    float Radius;
    float Mass;
    float Density;
    float Gravity;
    string Type;
    string Time;
    string planet_name;

public:

    //default constructor
    Planet()
    {
        planet_name  = " ";
        Radius = 0.0;
        Mass = 0.0;
        Density = 0.0;
        Gravity = 0.0;
        Type = " ";
        Time = " ";
    }

    //parametrized constructor for planet
    // Planet(string name, float r, float m, float d, float g, string type, string time)
    // {
    //     planet_name = name;
    //     Radius = r;
    //     Mass = m;
    //     Density = d;
    //     Gravity = g;
    //     Type = type;
    //     Time = time;
    // }

    //other parametrized constructor for use in class moon
    // Planet(float r, float m, float d, float g) {
    //     Radius = r;
    //     Mass = m;
    //     Density = d;
    //     Gravity = g;
    // }

    //setters & getters for planet class
    void set_planet_name(string name)
    {
        planet_name = name;
    }

    string get_name_planet()
    {
        return planet_name;
    }

    void set_radius(float r)
    {
        Radius = r;
    }

    float get_radius()
    {
        return Radius;
    }

    void set_mass(float m)
    {
        Mass = m;
    }

    float get_mass()
    {
        return Mass;
    }

    void set_density(float d)
    {
        Density = d;
    }
    
    float get_density()
    {
        return Density;
    }

    void set_gravity(float g)
    {
        Gravity = g;
    }

    float get_gravity()
    {
        return Gravity;
    }

    void set_type(string type)
    {
        Type = type;
    }

    string get_type()
    {
        return Type;
    }
    
    void set_time(string time)
    {
        Time = time;
    }

    string get_time()
    {
        return Time;
    }

    //function for search for a planet
    void search(string name)
    {
        if (planet_name == name)
        {
            display();
        }
    }

    //Salma's part (display info about planets)
    void display()
    {
        cout << endl << "-----------------------------------------------\n";
        cout << "Information about it:\n";
        cout << "1) Radius: " << Radius << endl;
        cout << "2) Mass: " << Mass << endl;
        cout << "3) Density: " << Density << endl;
        cout << "4) Gravity: " << Gravity << endl;
        cout << "5) Type: " << Type << endl;
        cout << "6) Time (compared to Earth's time): " << Time << endl;
    }
};

//Alaa's part
class Moon : public Planet
{
private :
    string around_planet;
    string moon_type;
    string moon_name;

public:

    //default constructor for moon
    Moon() :Planet()
    {
        around_planet = " ";
        moon_type = " ";
        moon_name = " ";
    }

    //parametrized constructor for moon
    // Moon(string m, string mn,string ap, float a, float b, float c, float d) :Planet(a, b, c, d)
    // {
    //     around_planet=ap;
    //     moon_type = m;
    //     moon_name = mn;
    // }

    //setters & getters for moon class
    void set_around_planet(string ap)
    {
        around_planet = ap;
    }

    string get_around_planet()
    {
        return around_planet;
    }

    void set_moon_type(string mt)
    {
        moon_type = mt;
    }

    string get_moon_type()
    {
        return moon_type;
    }

    void set_moon_name(string  mn)
    {
        moon_name = mn;
    }

    string  get_moon_name()
    {
        return moon_name;
    }

    //Salam's part (display info about moons)
    void dispaly()
    {
        cout << endl << "-----------------------------------------------\n";
        cout << "Information about it:\n";
        cout << "1) Radius: " << get_radius() << endl;
        cout << "2) Mass: " << get_mass() << endl;
        cout << "3) Density: " << get_density() << endl;
        cout << "4) Gravity: " << get_gravity() << endl;

        cout<<"(5)This moon revolves around planet:"<<around_planet<<endl;
        cout <<"(6)moon type:" << moon_type << endl;
        cout <<"(7)moon name:" << moon_name << endl;
        cout<<"-----------------------------------------------\n";
    }
};

//Esraa's part
#include <iostream>
#include <string>
#include <math.h>
using namespace std;

class Sun
{
    int temp_surface ;
    int temp_core ;
    int Speed_of_Light_in_Vacuum;
    float photon_travel_time;
    int Radius_of_the_earth;
    double Mass_of_the_earth;

public:
    Sun ()
    {
        temp_surface = 6000;
        temp_core = 15000000 ;
        Speed_of_Light_in_Vacuum = 300000;
        Radius_of_the_earth = 6371;
        Mass_of_the_earth = 5.9722 * pow(10,24);
    }

    void Distance_of_planets_from_Sun ()
    {
        cout << "Distance of planets from the sun : " << endl <<endl;

        cout << "Distance of Mercury from the Sun is : " << distance_from_sun(193) << " km." << endl << endl;
        cout << "------------------------------------------------------------" << endl << endl;

        cout << "Distance of Venus from the Sun is : " << distance_from_sun(360) << " km." << endl << endl;
        cout << "------------------------------------------------------------" << endl << endl;

        cout << "Distance of Earth from the Sun is : " << distance_from_sun(499) << " km." << endl << endl;
        cout << "------------------------------------------------------------" << endl << endl;

        cout << "Distance of Mars from the Sun is : " << distance_from_sun(759.9) << " km." << endl << endl;
        cout << "------------------------------------------------------------" << endl << endl;

        cout << "Distance of Jupiter from the Sun is : " << distance_from_sun(2595) << " km." << endl << endl;
        cout << "------------------------------------------------------------" << endl << endl;

        cout << "Distance of Saturn from the Sun is : " << distance_from_sun(4759) << " km." << endl << endl;
        cout << "------------------------------------------------------------" << endl << endl;

        cout << "Distance of Uranus from the Sun is : " << distance_from_sun(9575) << " km." << endl << endl;
        cout << "------------------------------------------------------------" << endl << endl;

        cout << "Distance of Neptune from the Sun is : " << distance_from_sun(14998) << " km." << endl << endl;
        cout << "------------------------------------------------------------" << endl << endl;

        cout << "Distance of Pluto/ Kuiper belt from the Sun is : " << distance_from_sun(19680) << " km." << endl << endl;
        cout << "------------------------------------------------------------" << endl << endl;
    }

    int  get_Temperature_on_surface()
    {
        return temp_surface;
    }

    int get_Temperature_of_core ()
    {
        return temp_core;
    }

    float distance_from_sun(float photon_travel)
    {
        float Distance;
        Distance = Speed_of_Light_in_Vacuum * photon_travel;

        return Distance;
    }

    double Mass_of_the_Sun()
    {
        double Sun_mass;

        Sun_mass = Mass_of_the_earth * 330000;

        return Sun_mass;
    }

    int Radius_of_the_Sun()
    {
        int Sun_radius;

        Sun_radius = Radius_of_the_earth * 109;

        return Sun_radius;
    }

    void Elements_of_Sun (string h,string he)
    {
        h = "hydrogen";
        he = "helium";
        cout << "Sun elements : " << "Roughly three-quarters of the Sun's mass consists of : " << h << " (~73%); the rest is mostly " << he <<" (~25%) ."<<endl ;
    }

    void Elements_of_Sun (string o,string c,string n,string fe)
    {
        o = "oxygen";
        c = "carbon";
        n = "neon";
        fe = "iron";
        cout << " with much smaller quantities of heavier elements, including : " << o << " , " << c << " , " << n << " and " << fe  << " ."<<endl;
    }

    void display()
    {
        cout << "Information about the sun:" << endl;
        cout << "1) Sun's mass: " << Mass_of_the_Sun() << endl;
        cout << "2) Sun's radius: " << Radius_of_the_Sun() << endl;
        cout << "3) ";
        Elements_of_Sun("hydrogen", "helium");
        cout << "4) ";
        Elements_of_Sun("oxygen", "carbon", "neon", "iron");
        cout << "5) ";
        Distance_of_planets_from_Sun();
        cout<<endl;
    }

};

int main() {
    
    
    return 0;
}